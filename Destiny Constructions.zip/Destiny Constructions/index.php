
<!DOCTYPE html>

<head><title>Destiny Constructions</title>
<meta name="Author" content=" Vitumbiko Nyambose" />
<link type="text/css" href="destinycss/destiny.css" media="all" rel="stylesheet" />
</head>


<body>
<div class="parent" >
<img src ="logo/DCs.jpg" alt= "Destiny Constructions"">

			<div class="child">
		<p>Destiny </br >Constructions</p>
		</div>
    <p></p>

		<div class="child1">
			<p><ul >
			<li><a href="index.php" target="_self">Home</li></a>
			&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<li><a href="pictures.php" target="_self">Pictures<a /></li>
			&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<li><a href="videos.php" target="_self">Videos<a /></li>
			&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<li><a href="" target="_self">Services <a /></li>
			&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<li><a href="" target="_self">About <a /></li>
			&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<li><a href="" target="_self">Contact <a /></li>
			&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<li><a href="db\login.php" target="_self">Members <a /></li>
			</ul></p>

					<div class="child2" class="w3-content w3-section" style="max-width:500px">
		           <center>pictures</center>



			        <img class="mySlides w3-animate-fading" src ="pictures/5fede96de496e2e037b14d3dc2a52290_hd.jpg" alt= "IMAGES"style="width:100%" >
			        <img class="mySlides w3-animate-fading" src ="pictures/images1.jpg" alt= "IMAGES"style="width:100%"  >
			        <img class="mySlides w3-animate-fading" src ="pictures/38260188-blueprints-and-construction-tools-with-hard-hat-.jpg" alt= "IMAGES"style="width:100%" >
			        <img class="mySlides w3-animate-fading" src ="pictures/heliconia-homes-elevation-12215530.jpeg" alt= "IMAGES"style="width:100%" >
			        <img class="mySlides w3-animate-fading" src ="pictures/heliconia-homes-elevation-12215536.jpeg" alt= "IMAGES"style="width:100%" >
			        <img class="mySlides w3-animate-fading" src ="pictures/home-design-kerala-thumb.jpg" alt= "IMAGES"style="width:100%" >
			        <img class="mySlides w3-animate-fading" src ="pictures/landmark-iii-elevation-24553261.jpeg" alt= "IMAGES" style="width:100%">

							<script>
 				 				var myIndex = 0;
 				 				carousel();

 				 				function carousel(){
 				 					 var i;
 				 				var x = document.getElementsByClassName("mySlides")
 				 				for (i = 0; i < x.length; i++) {
 				 					x[i].style.display = "none";
 				 				}
 				 				myIndex++;
 				 				if (myIndex > x.length) {myIndex = 1}
 				 				x[myIndex-1].style.display = "block";
 				 				setTimeout(carousel, 9000); //change image every 10 seconds
 				 				}
 				      </script>

         </div>

		<script>
				var myIndex = 0;
				carousel();

				function carousel(){
					 var i;
				var x = document.getElementsByClassName("mySlides")
				for (i = 0; i < x.length; i++) {
					x[i].style.display = "none";
				}
				myIndex++;
				if (myIndex > x.length) {myIndex = 1}
				x[myIndex-1].style.display = "block";
				setTimeout(carousel, 9000); //change image every 10 seconds
				}
     </script>

		<div class="child4">
		<center>Details</center>
		<p font-size="12">Destiny Constructions is a construnction company that</br> aims at building houses, innovating and different building</p>
		</div>

		</div>

    <p></p>

	    <div align ="center" class="child3">
			 Copyright&#169; 2019 destinyconstructions.com


		 </div>
</div>
</body>
</html>
