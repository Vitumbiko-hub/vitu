<!DOCTYPE html>
<html>
<head></head>
<body>

<video src="videofile.ogg" autoplay poster="posterimage.jpg">

</video>

</body>
</html>
