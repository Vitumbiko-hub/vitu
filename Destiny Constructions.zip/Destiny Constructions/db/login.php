<!doctype html>
<html>
<head>
   <meta charset="utf-8">
   <title> ADMIN PANEL</title>
   <link type="text/css"  href="login1.css" rel="stylesheet">

   </head>
   <body>
      <div class="box">
	  <h2>ADMIN PANEL</h2>
	  <form>
	     <div class="inputBox">
		      <input type="text" name="" required="">
			  <label>Username</label>
		 </div>
		 <div class="inputBox">
		      <input type="password" name="" required="">
			  <label>Password</label>
		 </div>
		 <input type="submit" name="" value="Login">
	  </form>
	  </div>
   </body>

</html>
